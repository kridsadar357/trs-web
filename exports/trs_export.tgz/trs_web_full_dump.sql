-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: trs_web
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `providerAccountId` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `refresh_token` text COLLATE utf8mb4_unicode_ci,
  `access_token` text COLLATE utf8mb4_unicode_ci,
  `expires_at` int DEFAULT NULL,
  `token_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scope` text COLLATE utf8mb4_unicode_ci,
  `id_token` text COLLATE utf8mb4_unicode_ci,
  `session_state` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Account_provider_providerAccountId_key` (`provider`,`providerAccountId`),
  KEY `Account_userId_fkey` (`userId`),
  CONSTRAINT `Account_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blogpost`
--

DROP TABLE IF EXISTS `blogpost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blogpost` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `excerpt` text COLLATE utf8mb4_unicode_ci,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `coverImage` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tags` json DEFAULT NULL,
  `authorId` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `authorName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `featured` tinyint(1) NOT NULL DEFAULT '0',
  `publishedAt` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `BlogPost_slug_key` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blogpost`
--

LOCK TABLES `blogpost` WRITE;
/*!40000 ALTER TABLE `blogpost` DISABLE KEYS */;
INSERT INTO `blogpost` VALUES ('cmnfov2s9000onkt0gp5yjgzu','ผู้ดูแล Axios ระบุถูกคนหลอกให้ติดตั้งโปรแกรมเพื่อเข้าประชุม เครื่องจึงถูกแฮก','axios-hacked','จากข่าวก่อนหน้า ที่มีการตรวจพบมัลแวร์ใน axios ซึ่งเป็น library ยอดนิยม และมีการปล่อยแพ็กเกจอันตรายขึ้น npm ล่าสุด Jason Saayman ผู้ดูแลโครงการได้ออกมาเปิดเผยรายละเอียดเหตุการณ์ (Post Mortem) ตั้งแต่จุดเริ่มต้นของการโจมตีว่า ไม่ได้มาจากช่องโหว่ทางเทคนิคโดยตรง แต่เป็นการทำ social engineering ที่ออกแบบมาเฉพาะตัวเขา โดยมีลำดับเหตุการณ์ตามนี้','<p>จาก<a target=\"_blank\" rel=\"noopener noreferrer nofollow\" class=\"text-primary underline\" href=\"https://www.blognone.com/node/150163\">ข่าวก่อนหน้า</a> ที่มีการตรวจพบมัลแวร์ใน axios ซึ่งเป็น library ยอดนิยม และมีการปล่อยแพ็กเกจอันตรายขึ้น npm ล่าสุด Jason Saayman ผู้ดูแลโครงการได้ออกมาเปิดเผยรายละเอียดเหตุการณ์ (Post Mortem) ตั้งแต่จุดเริ่มต้นของการโจมตีว่า ไม่ได้มาจากช่องโหว่ทางเทคนิคโดยตรง แต่เป็นการทำ social engineering ที่ออกแบบมาเฉพาะตัวเขา โดยมีลำดับเหตุการณ์ตามนี้</p><ul><li><p>ทักมาหาโดยปลอมตัวเป็น founder ของบริษัทแห่งหนึ่ง ซึ่งเลียนแบบทั้งตัวตนและตัวบริษัท</p></li><li><p>เชิญเข้า Slack workspace ที่มี branding, channel และ activity ของบริษัทนั้นอย่างสมจริง</p></li><li><p>ยกตัวอย่าง เช่น ใน Slack ก็มีการแชร์โพสต์ LinkedIn ที่ลิงก์ไปยังบัญชีจริงของบริษัทนั้นด้วย</p></li><li><p>มีการปลอม account ทีมงานและผู้ดูแล OSS หลายคนเพื่อสร้างความน่าเชื่อถือ</p></li><li><p>นัดประชุมผ่าน Microsoft Teams พร้อมผู้เข้าร่วมหลายคน</p></li><li><p>ระบบประชุมขึ้นเตือนว่าบางอย่าง outdated และต้องติดตั้งซอฟต์แวร์เพื่อให้เข้าประชุมได้</p></li><li><p>ซอฟต์แวร์ดังกล่าวคือ RAT (remote access trojan) ที่ใช้ในการเข้าถึงเครื่องและ credential นั้นเอง</p></li></ul><p>เหตุการณ์นี้ทำให้คนที่โจมตีสามารถใช้สิทธิ์ของผู้ดูแล ในการ publish แพ็กเกจที่ถูกฝังมัลแวร์ขึ้น npm ได้ และแม้ช่วงเวลาที่แพ็กเกจอันตรายจะอยู่บนระบบจะสั้น แต่ด้วยการใช้งานของ axios ที่แพร่หลาย จึงมีโอกาสกระทบ downstream จำนวนมากใน ecosystem ทันที แต่โชคยังดีอยู่บ้างที่เหตุการณ์นี้ถูกตรวจสอบเจอและปิดช่องโหว่ได้ภายในเวลาไม่กี่ชั่วโมง ตามลำดับเหตุการณ์</p><ul><li><p>ประมาณ 2 สัปดาห์ก่อนวันที่ 31 มีนาคม มีการเริ่ม social engineering campaign กับผู้ดูแลระบบ</p></li><li><p>วันที่ 30 มีนาคม เวลา 05:57 UTC มีการปล่อย plain-crypto-js 4.2.0 ขึ้น npm</p></li><li><p>วันที่ 31 มีนาคม เวลา 00:21 UTC มีการปล่อย axios 1.14.1 พร้อม plain-crypto-js 4.2.1</p></li><li><p>ราว 01:00 UTC มีการปล่อย axios 0.30.4 พร้อม payload เดียวกัน</p></li><li><p>ราว 01:00 UTC เริ่มมีการตรวจพบจากภายนอก และมีผู้ใช้เปิด issue แจ้งเหตุ แต่ issue ถูกลบผ่านบัญชีที่ถูกยึด</p></li><li><p>เวลา 01:38 UTC ผู้ร่วมโครงการอีกคนเปิด PR เพื่อ deprecate เวอร์ชันที่ถูก compromise และติดต่อ npm โดยตรง</p></li><li><p>เวลา 03:15 UTC เวอร์ชันอันตรายของ axios ถูกลบออกจาก npm</p></li><li><p>เวลา 03:29 UTC plain-crypto-js ถูกลบออกจาก npm</p></li></ul><p>ที่มา: <a target=\"_blank\" rel=\"noopener noreferrer nofollow\" class=\"text-primary underline\" href=\"https://github.com/axios/axios/issues/10636\">axios issue#10636</a></p><img src=\"/uploads/926d194b-9b65-48fb-8151-6a4cd8c6c6c6.png\">','/uploads/9e87119e-da36-4d41-a6b9-bd6d269db0e5.png','Technology','[\"Security\", \"NPM\", \"Social Engineering\"]',NULL,'Alex Thompson',1,1,'2026-04-01 06:52:37.207','2026-04-01 06:52:37.210','2026-04-05 16:14:39.467'),('cmnfov2sd000pnkt0s939aull','Matt Mullenweg วิจารณ์ EmDash บอกของดี แต่สร้างมาเพื่อขายบริการ Cloudflare','mullenweg-emdash-cloudflare','การเปิดตัว EmDash ของ Cloudflare ที่ตั้งใจมาชน WordPress ตรงๆ ย่อมสร้างเสียงฮือฮาให้วงการ CMS เป็นอย่างมาก และประเด็นนี้คงไม่มีใครสามารถคอมเมนต์ได้ดีกว่า Matt Mullenweg ผู้สร้าง WordPress\n\nMatt เขียนแสดงความเห็นในบล็อกของตัวเอง ว่าทีม Cloudflare เคยมาหารือ และนำ EmDash มาโชว์ให้ดูก่อนหน้านี้แล้ว ส่วนความเห็นของเขาคือ','<img src=\"https://www.blognone.com/sites/default/files/topics-images/emdash.png\" alt=\"EmDash\"><p><a target=\"_blank\" rel=\"noopener noreferrer nofollow\" class=\"text-primary underline\" href=\"https://www.blognone.com/node/150190\">การเปิดตัว EmDash ของ Cloudflare ที่ตั้งใจมาชน WordPress ตรงๆ</a> ย่อมสร้างเสียงฮือฮาให้วงการ CMS เป็นอย่างมาก และประเด็นนี้คงไม่มีใครสามารถคอมเมนต์ได้ดีกว่า Matt Mullenweg ผู้สร้าง WordPress</p><p>Matt เขียนแสดงความเห็นในบล็อกของตัวเอง ว่าทีม Cloudflare เคยมาหารือ และนำ EmDash มาโชว์ให้ดูก่อนหน้านี้แล้ว ส่วนความเห็นของเขาคือ</p><ul><li><p>เขาชื่นชมบริษัท Cloudflare อยู่ก่อนแล้ว และเห็นด้วยที่ Cloudflare ทำ CMS ที่เป็นโอเพนซอร์ส มีจิตวิญญาณเปิดกว้างแบบเดียวกับ WordPress</p></li><li><p>เขามองว่า EmDash เกิดมาเพื่อช่วยให้ Cloudflare ขายบริการของตัวเองได้มากขึ้น (ซึ่งเขามองว่าเป็นสิ่งที่โอเค) แม้เราสามารถรัน EmDash บนระบบอื่นได้ แต่มันจะทำงานได้ดีที่สุดบน Cloudflare และจะบังคับทางอ้อมให้เราถูกล็อคกับระบบของ Cloudflare ไปยาวๆ</p></li><li><p>ตัวผลิตภัณฑ์ EmDash ออกมาแน่น (solid) ทำงานได้รวดเร็ว การเชื่อมกับ Astro เป็นสิ่งที่ดี</p></li><li><p>UI หน้าตาคล้าย WordPress แต่ก็ไม่เหมือนซะทีเดียว</p></li><li><p>เขาวิจารณ์ว่า EmDash เลือกใช้ <a target=\"_blank\" rel=\"noopener noreferrer nofollow\" class=\"text-primary underline\" href=\"https://www.portabletext.org/\">Portable Text</a> เป็นตัวแก้ไขเนื้อหา ควรจะใช้ Gutenberg ของ WordPress ดีกว่า</p></li><li><p>ฟีเจอร์ Agent Skills เจ๋ง และ WordPress ควรทำตามบ้าง</p></li><li><p>เขาบอกว่า EmDash ลอกฟีเจอร์บางอย่างของ WordPress ที่กำลังจะเลิกทำ แต่ไม่บอกว่าเป็นฟีเจอร์ไหน</p></li><li><p>เขาตอบโต้ประเด็นความปลอดภัยของปลั๊กอิน WordPress ว่าการมีปลั๊กอินในระบบเยอะถึง 62,000 ตัวย่อมมีช่องโหว่ แต่ WordPress จะแก้ปัญหานี้ภายใน 18 เดือนข้างหน้าด้วย AI</p></li><li><p>ส่วนแนวคิดการรันปลั๊กอินใน sandbox ของ EmDash จะไม่เวิร์ค และฟีเจอร์ความปลอดภัยปลั๊กอินจะทำงานได้เฉพาะบนเซิร์ฟเวอร์ Cloudflare เท่านั้น</p></li></ul><p>ที่มา - <a target=\"_blank\" rel=\"noopener noreferrer nofollow\" class=\"text-primary underline\" href=\"https://ma.tt/2026/04/emdash-feedback/\">Matt Mullenweg</a></p>','/uploads/ceda54b6-b871-4eea-a85e-a6d5b9eb5c9d.webp','CMS','[\"EmDash\", \"WordPress\", \"CMS\", \"Cloudflare\", \"Automatic\"]',NULL,'Matt Mullenweg',1,0,'2026-04-01 06:52:37.207','2026-04-01 06:52:37.213','2026-04-05 16:13:07.533');
/*!40000 ALTER TABLE `blogpost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contactsubmission`
--

DROP TABLE IF EXISTS `contactsubmission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contactsubmission` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'new',
  `read` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contactsubmission`
--

LOCK TABLES `contactsubmission` WRITE;
/*!40000 ALTER TABLE `contactsubmission` DISABLE KEYS */;
INSERT INTO `contactsubmission` VALUES ('cmnh4sdws0000nkm0oy4a1onb','กฤษดา งานขยัน','kridsadar357@gmail.com','0983631398','TKGH Group Co., LTD','เริ่มคำนวณ Scale งาน','asfasf','new',0,'2026-04-02 07:06:11.691','2026-04-02 07:06:22.801');
/*!40000 ALTER TABLE `contactsubmission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `page`
--

DROP TABLE IF EXISTS `page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `page` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` json DEFAULT NULL,
  `heroTitle` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `heroSubtitle` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `heroImage` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metaDescription` text COLLATE utf8mb4_unicode_ci,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `order` int NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Page_slug_key` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page`
--

LOCK TABLES `page` WRITE;
/*!40000 ALTER TABLE `page` DISABLE KEYS */;
INSERT INTO `page` VALUES ('cmnfov2q70001nkt09qx6tb22','home','Home',NULL,'We Build Digital Experiences','TRS — Where Innovation Meets Design',NULL,NULL,1,0,'2026-04-01 06:52:37.135','2026-04-01 06:52:37.135'),('cmnfov2qa0002nkt0csz4rwhj','about','About Us',NULL,'Our Story','Passionate about delivering exceptional digital solutions',NULL,NULL,1,1,'2026-04-01 06:52:37.139','2026-04-01 06:52:37.139'),('cmnfov2qf0003nkt0tgvfy7c9','services','Services',NULL,'What We Do','Comprehensive digital solutions for your business',NULL,NULL,1,2,'2026-04-01 06:52:37.143','2026-04-01 06:52:37.143'),('cmnfov2qi0004nkt01gfg1ge9','portfolio','Portfolio',NULL,'Our Work','Showcasing our best projects and achievements',NULL,NULL,1,3,'2026-04-01 06:52:37.147','2026-04-01 06:52:37.147'),('cmnfov2ql0005nkt0anxwvija','team','Team',NULL,'Meet Our Team','The talented people behind TRS',NULL,NULL,1,4,'2026-04-01 06:52:37.149','2026-04-01 06:52:37.149'),('cmnfov2qo0006nkt0pthxu04o','blog','Blog',NULL,'Insights & News','Thoughts on technology, design, and business',NULL,NULL,1,5,'2026-04-01 06:52:37.153','2026-04-01 06:52:37.153'),('cmnfov2qr0007nkt0pdxc163o','contact','Contact',NULL,'Get In Touch','Let\'s start a conversation',NULL,NULL,1,6,'2026-04-01 06:52:37.155','2026-04-01 06:52:37.155');
/*!40000 ALTER TABLE `page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portfolioitem`
--

DROP TABLE IF EXISTS `portfolioitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `portfolioitem` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `client` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `technologies` json DEFAULT NULL,
  `imageUrl` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gallery` json DEFAULT NULL,
  `featured` tinyint(1) NOT NULL DEFAULT '0',
  `completedAt` datetime(3) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `PortfolioItem_slug_key` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portfolioitem`
--

LOCK TABLES `portfolioitem` WRITE;
/*!40000 ALTER TABLE `portfolioitem` DISABLE KEYS */;
INSERT INTO `portfolioitem` VALUES ('cmnfov2s4000nnkt0vx8rpout','FPOS โปรแกรมสถานีขายน้ำมัน','fpos-','โปรแกรม POS สถานีขายน้ำมันทำงานคู่กับ controller เชื่อมต่อกับตู้จ่าย ระบบ Authorize ยืดหยุ่นปรับเปลี่ยนได้','<img src=\"/uploads/75547322-7f51-432e-86ef-85f449aecbd1.png\"><p><span style=\"color: rgb(255, 255, 255);\"><strong>โปรแกรม POS สถานีขายน้ำมันทำงานคู่กับ controller เชื่อมต่อกับตู้จ่าย ระบบ Authorize ยืดหยุ่นปรับเปลี่ยนได้</strong></span></p><p></p><ol><li><p><span style=\"color: rgb(255, 255, 255);\"><strong><em>เชื่อมต่อกับตู้รุ่นต่างๆได้มากมาย</em></strong></span></p></li><li><p><span style=\"color: rgb(255, 255, 255);\"><strong><em>หน้าตาโปรแกรมสมัยใหม่</em></strong></span></p></li><li><p><span style=\"color: rgb(255, 255, 255);\"><strong><em>พิมพ์ใบกำกับภาษีเต็มรูปแบบได้ โปรแกรมตั้งขาย vat ได้</em></strong></span></p></li><li><p><span style=\"color: rgb(255, 255, 255);\"><strong><em>ปรับราคาน้ำมันทางออนไลน์หรือหน้าขายได้โดยตรง</em></strong></span></p></li><li><p><span style=\"color: rgb(255, 255, 255);\"><strong><em>รายงานข้อมูลแยกประเภทการขาย,ประเภทชำระเงิน,การขายตามหัวจ่าย,ประเภทน้ำมัน แบบเป็นกะหรือวันแบบชัดเจน</em></strong></span></p></li><li><p><span style=\"color: rgb(255, 255, 255);\"><strong><em>แจ้งเตือนน้ำมันใกล้จะหมดตามการตัดสต็อคน้ำมันผ่าน Telegram หรือ Line</em></strong></span></p></li><li><p><span style=\"color: rgb(255, 255, 255);\"><strong><em>เมนูการบีบทดสอบน้ำมันและแยกรายงานได้</em></strong></span></p></li><li><p><span style=\"color: rgb(255, 255, 255);\"><strong><em>เจ้าของธุรกิจสามารถจัดการหลังบ้านได้สะดวก รวดเร็ว</em></strong></span></p></li><li><p><span style=\"color: rgb(255, 255, 255);\"><strong><em>กะการทำงานไม่จำกัดและสามารถเปิดกะได้หลายกะทำงานใน 1 วัน (1:N)</em></strong></span></p></li><li><p><span style=\"color: rgb(255, 255, 255);\"><strong><em>มีหน้าการขายสินค้าอื่นๆ เช่น น้ำมันเครื่องและสินค้าทั่วไป</em></strong></span></p></li><li><p><span style=\"color: rgb(255, 255, 255);\"><strong><em>ฟังก์ชั่นอื่นๆอีกมากมายเลยครับ</em></strong></span></p></li><li><p><span style=\"color: rgb(255, 255, 255);\"><strong><em>ฟรีระบบสะสมแต้มบน Line OA</em></strong></span></p></li><li><p><span style=\"color: rgb(255, 255, 255);\"><strong><em>ฟรีดูยอดขาย Online</em></strong></span></p></li><li><p><span style=\"color: rgb(255, 255, 255);\"><strong><em>ฟรีดูสต็อคน้ำมันออนไลน์ ( Non-ATG )<br><br>ลูกค้าท่านใดต้องการดู Demo สามารถทักมาสอบถามได้</em></strong></span></p><p><span style=\"color: rgb(255, 255, 255);\"><strong><em>เรามีบริการมากมาย เช่น ระบบตรวจวัดระดับน้ำมัน ( ATG ) , และออกแบบระบบเพิ่มเติมอื่นๆตามความต้องการลูกค้าได้ครับ</em></strong></span></p></li></ol><div data-youtube-video=\"\"><iframe width=\"640\" height=\"360\" allowfullscreen=\"true\" autoplay=\"false\" disablekbcontrols=\"false\" enableiframeapi=\"false\" endtime=\"0\" ivloadpolicy=\"0\" loop=\"false\" modestbranding=\"false\" origin=\"\" playlist=\"\" rel=\"1\" src=\"https://www.youtube-nocookie.com/embed/MEag-_MtSF4?start=16&amp;rel=1\" start=\"0\"></iframe></div>','FPOS','PC App','[\"React Native\", \"Python\", \"Javascript\", \"Rust\"]','/uploads/a936b78b-d0cc-4457-9a40-b05653562481.png','[\"/uploads/d75030de-78bb-404e-b166-8de50c0177af.png\", \"/uploads/c0fb39cd-ff53-4b97-9c53-2c5670820042.png\", \"/uploads/50543fb9-0c23-4931-8474-79e8e6ef76c5.png\", \"/uploads/bc5bb733-e23b-4d7c-ad8e-384c63d28f2b.png\", \"/uploads/9202c510-7f73-4bd9-86b5-9ac317c12d01.png\", \"/uploads/59508a43-0e53-46c7-b549-43e415a2d2be.png\"]',1,NULL,1,'2026-04-01 06:52:37.204','2026-04-05 15:50:19.648');
/*!40000 ALTER TABLE `portfolioitem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service`
--

DROP TABLE IF EXISTS `service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `features` json DEFAULT NULL,
  `order` int NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `coverImage` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `detailContent` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Service_slug_key` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service`
--

LOCK TABLES `service` WRITE;
/*!40000 ALTER TABLE `service` DISABLE KEYS */;
INSERT INTO `service` VALUES ('cmnfov2qv0008nkt0ovmpvq5a','FPOS โปรแกรมสถานนีขายน้ำมัน','fpos-appliation','โปรแกรม POS สถานีขายน้ำมันทำงานคู่กับ controller เชื่อมต่อกับตู้จ่าย ระบบ Authorize ยืดหยุ่นปรับเปลี่ยนได้','Code','[\"หน้าขาย\", \"หลังลาน\", \"ระบบชำระเงิน\", \"ระบบสมาชิก\", \"ระบบโปรโมชั่น\", \"รายงานการขายครบครัน\", \"ใบกำกับภาษีเต็ม/ย่อ\", \"ดูยอดขายออนไลน์\", \"ดูยอดน้ำมันออนไลน์\", \"อื่นๆ\"]',0,1,'2026-04-01 06:52:37.159','2026-04-02 04:51:21.703','/uploads/2d5e056b-be81-4c09-9be1-b98d76eb6efd.png','<p><strong>โปรแกรม POS สถานีขายน้ำมันทำงานคู่กับ controller เชื่อมต่อกับตู้จ่าย ระบบ Authorize ยืดหยุ่นปรับเปลี่ยนได้</strong></p><ul><li><p>เชื่อมต่อกับตู้รุ่นต่างๆได้มากมาย</p></li><li><p>หน้าตาโปรแกรมสมัยใหม่</p></li><li><p>พิมพ์ใบกำกับภาษีเต็มรูปแบบได้ โปรแกรมตั้งขาย vat ได้</p></li><li><p>ปรับราคาน้ำมันทางออนไลน์หรือหน้าขายได้โดยตรง</p></li><li><p>รายงานข้อมูลแยกประเภทการขาย,ประเภทชำระเงิน,การขายตามหัวจ่าย,ประเภทน้ำมัน แบบเป็นกะหรือวันแบบชัดเจน</p></li><li><p>แจ้งเตือนน้ำมันใกล้จะหมดตามการตัดสต็อคน้ำมันผ่าน Telegram หรือ Line</p></li><li><p>เมนูการบีบทดสอบน้ำมันและแยกรายงานได้</p></li><li><p>เจ้าของธุรกิจสามารถจัดการหลังบ้านได้สะดวก รวดเร็ว</p></li><li><p>กะการทำงานไม่จำกัดและสามารถเปิดกะได้หลายกะทำงานใน 1 วัน (1:N)</p></li><li><p>มีหน้าการขายสินค้าอื่นๆ เช่น น้ำมันเครื่องและสินค้าทั่วไป</p></li><li><p>ฟังก์ชั่นอื่นๆอีกมากมายเลยครับ</p></li><li><p>ฟรีระบบสะสมแต้มบน Line OA</p></li><li><p>ฟรีดูยอดขาย Online</p></li><li><p>ฟรีดูสต็อคน้ำมันออนไลน์ ( Non-ATG )</p></li></ul><img src=\"/uploads/fd8a37bc-fa56-44eb-ae89-6caca9e03fc9.png\"><h3>วิดิโอหน้าการขาย</h3><div data-youtube-video=\"\"><iframe width=\"640\" height=\"360\" allowfullscreen=\"true\" autoplay=\"false\" disablekbcontrols=\"false\" enableiframeapi=\"false\" endtime=\"0\" ivloadpolicy=\"0\" loop=\"false\" modestbranding=\"false\" origin=\"\" playlist=\"\" rel=\"1\" src=\"https://www.youtube-nocookie.com/embed/MEag-_MtSF4?rel=1\" start=\"0\"></iframe></div><h3><br>UI Interface โปรแกรม<br></h3><div data-items=\"[{&quot;src&quot;:&quot;/uploads/c2a73c07-52aa-4ec3-94bd-0a1e17f9121a.png&quot;,&quot;caption&quot;:&quot;&quot;},{&quot;src&quot;:&quot;/uploads/315530df-8120-440a-89c5-e87955170236.png&quot;,&quot;caption&quot;:&quot;&quot;},{&quot;src&quot;:&quot;/uploads/e9ba909d-2311-4c0b-970e-43868cba734e.png&quot;,&quot;caption&quot;:&quot;&quot;},{&quot;src&quot;:&quot;/uploads/884b5273-d3af-4a8b-b52e-d8e9e216a428.png&quot;,&quot;caption&quot;:&quot;&quot;},{&quot;src&quot;:&quot;/uploads/b477e09c-ce28-49e3-99ec-7f31df04644d.png&quot;,&quot;caption&quot;:&quot;&quot;},{&quot;src&quot;:&quot;/uploads/69d031b4-78bf-4502-bb63-b870d0597c63.png&quot;,&quot;caption&quot;:&quot;&quot;},{&quot;src&quot;:&quot;/uploads/fccc4b88-16d1-49b5-8dd2-00159790ca4a.png&quot;,&quot;caption&quot;:&quot;&quot;},{&quot;src&quot;:&quot;/uploads/bd9cb882-f97e-4fae-bc2e-533f99b58916.png&quot;,&quot;caption&quot;:&quot;&quot;},{&quot;src&quot;:&quot;/uploads/30de7bed-08dd-4941-919f-926dc8200be8.png&quot;,&quot;caption&quot;:&quot;เปลี่ยนราคาน้ำมัน&quot;}]\" class=\"rte-gallery\" data-rte-gallery=\"true\"><figure class=\"rte-gallery__figure\"><img src=\"/uploads/c2a73c07-52aa-4ec3-94bd-0a1e17f9121a.png\" alt=\"\" class=\"rte-gallery__img\" loading=\"lazy\"><figcaption class=\"rte-gallery__caption\"></figcaption></figure><figure class=\"rte-gallery__figure\"><img src=\"/uploads/315530df-8120-440a-89c5-e87955170236.png\" alt=\"\" class=\"rte-gallery__img\" loading=\"lazy\"><figcaption class=\"rte-gallery__caption\"></figcaption></figure><figure class=\"rte-gallery__figure\"><img src=\"/uploads/e9ba909d-2311-4c0b-970e-43868cba734e.png\" alt=\"\" class=\"rte-gallery__img\" loading=\"lazy\"><figcaption class=\"rte-gallery__caption\"></figcaption></figure><figure class=\"rte-gallery__figure\"><img src=\"/uploads/884b5273-d3af-4a8b-b52e-d8e9e216a428.png\" alt=\"\" class=\"rte-gallery__img\" loading=\"lazy\"><figcaption class=\"rte-gallery__caption\"></figcaption></figure><figure class=\"rte-gallery__figure\"><img src=\"/uploads/b477e09c-ce28-49e3-99ec-7f31df04644d.png\" alt=\"\" class=\"rte-gallery__img\" loading=\"lazy\"><figcaption class=\"rte-gallery__caption\"></figcaption></figure><figure class=\"rte-gallery__figure\"><img src=\"/uploads/69d031b4-78bf-4502-bb63-b870d0597c63.png\" alt=\"\" class=\"rte-gallery__img\" loading=\"lazy\"><figcaption class=\"rte-gallery__caption\"></figcaption></figure><figure class=\"rte-gallery__figure\"><img src=\"/uploads/fccc4b88-16d1-49b5-8dd2-00159790ca4a.png\" alt=\"\" class=\"rte-gallery__img\" loading=\"lazy\"><figcaption class=\"rte-gallery__caption\"></figcaption></figure><figure class=\"rte-gallery__figure\"><img src=\"/uploads/bd9cb882-f97e-4fae-bc2e-533f99b58916.png\" alt=\"\" class=\"rte-gallery__img\" loading=\"lazy\"><figcaption class=\"rte-gallery__caption\"></figcaption></figure><figure class=\"rte-gallery__figure\"><img src=\"/uploads/30de7bed-08dd-4941-919f-926dc8200be8.png\" alt=\"\" class=\"rte-gallery__img\" loading=\"lazy\"><figcaption class=\"rte-gallery__caption\">เปลี่ยนราคาน้ำมัน</figcaption></figure></div><p></p><p>✅สนใจติดตั้งหรือสอบถามข้อมูลเพิ่มเติม:</p><p>ทัก Inbox แชทเพจได้เลยครับ</p><p>Line : @trs-solutions (มี @ ด้านหน้า)</p><p>เว็บไซต์: <a target=\"_blank\" rel=\"noopener noreferrer nofollow\" class=\"text-primary underline\" href=\"https://ttmb-tech.com\"><strong>https://trs-solutions.com</strong></a></p><p>ลูกค้าท่านใดต้องการดู Demo สามารถทักมาสอบถามได้</p><p>ผมมีบริการมากมาย เช่น ระบบตรวจวัดระดับน้ำมัน ( ATG ) , และออกแบบระบบเพิ่มเติมอื่นๆตามความต้องการลูกค้า</p>'),('cmnfov2qz0009nkt0mg0jso4b','ATG-Clink','atg-clink','ATG C-Link Application ⛽️💧\nไม่ว่าคุณจะอยู่ที่ไหน ก็รู้ระดับน้ำมันในถังได้ทันที! เปลี่ยนการเช็คสต๊อกแบบเดิมๆ ให้เป็นเรื่องง่าย สะดวก\nและแม่นยำบนมือถือและแท็บเล็ตของคุณ','Palette','[\"Realtime\", \"ใช้งานง่าย\", \"รองรับหลายภาษา\", \"โหมด Always-On\"]',1,1,'2026-04-01 06:52:37.163','2026-04-02 05:34:32.142','/uploads/ff11c911-860c-4e36-af8c-1d909b6949cf.jpg','<div data-variant=\"info\" data-rte-callout=\"true\" class=\"rte-callout rte-callout--info\"><p>หมดยุคกังวลเรื่องสต๊อกน้ำมัน! บริหารปั๊มง่ายขึ้น ด้วย ATG Link Application ไม่ว่าคุณจะอยู่ที่ไหน ก็รู้ระดับน้ำมันในถังได้ทันที! เปลี่ยนการเช็คสต๊อกแบบเดิมๆ ให้เป็นเรื่องง่าย สะดวก และแม่นยำบนมือถือและแท็บเล็ตของคุณ</p></div><img src=\"/uploads/95c363ef-9624-4e7a-a6e5-d64217981fec.png\"><p></p><p>## ✨ ทำไมคุณถึงจะชอบมัน</p><p>- <strong>อัปเดตสด ⚡</strong>: ดูได้ทันทีว่าถังทำงานอย่างไร</p><p>- <strong>เชื่อมต่อแสนง่าย 🔗</strong>: ลิงก์อุปกรณ์ของคุณอย่างปลอดภัย เห็นเฉพาะถังที่คุณสนใจ</p><p>- <strong>กราฟสวยงาม 📊</strong>: ประวัติการใช้งานถังถูกเปลี่ยนเป็นกราฟที่อ่านง่ายและสวยงาม</p><p>- <strong>รองรับหลายภาษา 🌍</strong>: มีทั้งภาษาอังกฤษและภาษาไทย</p><p>- <strong>สบายตา 🎨</strong>: เลือกโหมด Light หรือ Dark ได้</p><p>- <strong>โหมด Always-On 🖥️</strong>: เปิดโหมดเต็มจอเพื่อดูแดชบอร์ดแบบต่อเนื่อง</p><p>ดูประวัติย้อนหลังได้: เช็คแนวโน้มและปริมาณย้อนหลังเพื่อการวางแผนที่แม่นยำ (ตามภาพหน้าจอประวัติ)</p><p>บริหารธุรกิจปั๊มน้ำมันอย่างมืออาชีพ ลดข้อผิดพลาด ประหยัดเวลา!</p><p></p><div class=\"rte-iframe-wrap\" data-rte-iframe-wrap=\"true\"><iframe src=\"https://www.facebook.com/plugins/video.php?height=476&amp;href=https%3A%2F%2Fwww.facebook.com%2Freel%2F1557778401952439%2F&amp;show_text=false&amp;width=267&amp;t=0\" title=\"Embedded content\" class=\"rte-iframe\" allowfullscreen=\"true\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share\"></iframe></div><p><br></p><div data-items=\"[{&quot;src&quot;:&quot;/uploads/f5726a82-971f-4635-994d-bcc2da59f033.jpg&quot;,&quot;caption&quot;:&quot;การเชื่อมต่ออุปกรณ์&quot;},{&quot;src&quot;:&quot;/uploads/d30d0800-9844-49e0-9c53-8fbf1162b99b.jpg&quot;,&quot;caption&quot;:&quot;การเข้าสู่ระบบ&quot;},{&quot;src&quot;:&quot;/uploads/9271a787-bb34-47c8-9e8b-ac61a0d2ef84.jpg&quot;,&quot;caption&quot;:&quot;รายละเอียดหน้าแรก&quot;},{&quot;src&quot;:&quot;/uploads/a38e55e0-6641-48b4-a604-5bf43e760060.jpg&quot;,&quot;caption&quot;:&quot;รายละเอียดเฉพาะถัง&quot;},{&quot;src&quot;:&quot;/uploads/50130fe7-dc45-4f07-af39-563f1d73b0fa.jpg&quot;,&quot;caption&quot;:&quot;กราฟวิเคราะห์สต็อคน้ำมัน&quot;}]\" class=\"rte-gallery\" data-rte-gallery=\"true\"><figure class=\"rte-gallery__figure\"><img src=\"/uploads/f5726a82-971f-4635-994d-bcc2da59f033.jpg\" alt=\"\" class=\"rte-gallery__img\" loading=\"lazy\"><figcaption class=\"rte-gallery__caption\">การเชื่อมต่ออุปกรณ์</figcaption></figure><figure class=\"rte-gallery__figure\"><img src=\"/uploads/d30d0800-9844-49e0-9c53-8fbf1162b99b.jpg\" alt=\"\" class=\"rte-gallery__img\" loading=\"lazy\"><figcaption class=\"rte-gallery__caption\">การเข้าสู่ระบบ</figcaption></figure><figure class=\"rte-gallery__figure\"><img src=\"/uploads/9271a787-bb34-47c8-9e8b-ac61a0d2ef84.jpg\" alt=\"\" class=\"rte-gallery__img\" loading=\"lazy\"><figcaption class=\"rte-gallery__caption\">รายละเอียดหน้าแรก</figcaption></figure><figure class=\"rte-gallery__figure\"><img src=\"/uploads/a38e55e0-6641-48b4-a604-5bf43e760060.jpg\" alt=\"\" class=\"rte-gallery__img\" loading=\"lazy\"><figcaption class=\"rte-gallery__caption\">รายละเอียดเฉพาะถัง</figcaption></figure><figure class=\"rte-gallery__figure\"><img src=\"/uploads/50130fe7-dc45-4f07-af39-563f1d73b0fa.jpg\" alt=\"\" class=\"rte-gallery__img\" loading=\"lazy\"><figcaption class=\"rte-gallery__caption\">กราฟวิเคราะห์สต็อคน้ำมัน</figcaption></figure></div><p></p><p>สนใจติดตั้งหรือสอบถามข้อมูลเพิ่มเติม:</p><ul><li><p>ทัก Inbox แชทเพจได้เลยครับ</p></li><li><p>Line : @trs-solutions (มี @ ด้านหน้า)</p></li><li><p>เว็บไซต์: <a target=\"_blank\" rel=\"noopener noreferrer nofollow\" class=\"text-primary underline\" href=\"https://ttmb-tech.com\"><strong>https://trs-nextgen.com</strong></a></p></li></ul><p><a target=\"_blank\" rel=\"noopener noreferrer nofollow\" class=\"text-primary underline x1i10hfl xjbqb8w x1ejq31n x18oe1m7 x1sy0etr xstzfhl x972fbf x10w94by x1qhh985 x14e42zd x9f619 x1ypdohk xt0psk2 x3ct3a4 xdj266r x14z9mp xat24cr x1lziwak xexx8yu xyri2b x18d9i69 x1c1uobl x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xkrqix3 x1sur9pj x1fey0fg x1s688f\" href=\"https://www.facebook.com/hashtag/atglink?__eep__=6&amp;__cft__[0]=AZaBVtN_fk-53uWSIi78PJqfuz7MnjQRF8sETRVnJpNBlmSpcVmMPid0y81OUaEPMpeer9iqjq9fTyoEvyMvflFYn7Y_tkcKLhIJOiI_Ll4rdyXejJYrsrddNf-rEjBU9mE8h9w0cbTre2CVdW6WDkJRE7N8rPPIbVZNw5I5SEP9rrDI7cmhRiVLm-GsHkqyVH0&amp;__tn__=*NK-R\"><strong>#ATGLink</strong></a> <a target=\"_blank\" rel=\"noopener noreferrer nofollow\" class=\"text-primary underline x1i10hfl xjbqb8w x1ejq31n x18oe1m7 x1sy0etr xstzfhl x972fbf x10w94by x1qhh985 x14e42zd x9f619 x1ypdohk xt0psk2 x3ct3a4 xdj266r x14z9mp xat24cr x1lziwak xexx8yu xyri2b x18d9i69 x1c1uobl x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xkrqix3 x1sur9pj x1fey0fg x1s688f\" href=\"https://www.facebook.com/hashtag/%E0%B8%A3%E0%B8%B0%E0%B8%9A%E0%B8%9A%E0%B8%A7%E0%B8%B1%E0%B8%94%E0%B8%A3%E0%B8%B0%E0%B8%94%E0%B8%B1%E0%B8%9A%E0%B8%99%E0%B9%89%E0%B8%B3%E0%B8%A1%E0%B8%B1%E0%B8%99?__eep__=6&amp;__cft__[0]=AZaBVtN_fk-53uWSIi78PJqfuz7MnjQRF8sETRVnJpNBlmSpcVmMPid0y81OUaEPMpeer9iqjq9fTyoEvyMvflFYn7Y_tkcKLhIJOiI_Ll4rdyXejJYrsrddNf-rEjBU9mE8h9w0cbTre2CVdW6WDkJRE7N8rPPIbVZNw5I5SEP9rrDI7cmhRiVLm-GsHkqyVH0&amp;__tn__=*NK-R\"><strong>#ระบบวัดระดับน้ำมัน</strong></a> <a target=\"_blank\" rel=\"noopener noreferrer nofollow\" class=\"text-primary underline x1i10hfl xjbqb8w x1ejq31n x18oe1m7 x1sy0etr xstzfhl x972fbf x10w94by x1qhh985 x14e42zd x9f619 x1ypdohk xt0psk2 x3ct3a4 xdj266r x14z9mp xat24cr x1lziwak xexx8yu xyri2b x18d9i69 x1c1uobl x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xkrqix3 x1sur9pj x1fey0fg x1s688f\" href=\"https://www.facebook.com/hashtag/%E0%B8%A3%E0%B8%B0%E0%B8%9A%E0%B8%9A%E0%B8%88%E0%B8%B1%E0%B8%94%E0%B8%81%E0%B8%B2%E0%B8%A3%E0%B8%9B%E0%B8%B1%E0%B9%8A%E0%B8%A1%E0%B8%99%E0%B9%89%E0%B8%B3%E0%B8%A1%E0%B8%B1%E0%B8%99?__eep__=6&amp;__cft__[0]=AZaBVtN_fk-53uWSIi78PJqfuz7MnjQRF8sETRVnJpNBlmSpcVmMPid0y81OUaEPMpeer9iqjq9fTyoEvyMvflFYn7Y_tkcKLhIJOiI_Ll4rdyXejJYrsrddNf-rEjBU9mE8h9w0cbTre2CVdW6WDkJRE7N8rPPIbVZNw5I5SEP9rrDI7cmhRiVLm-GsHkqyVH0&amp;__tn__=*NK-R\"><strong>#ระบบจัดการปั๊มน้ำมัน</strong></a> <a target=\"_blank\" rel=\"noopener noreferrer nofollow\" class=\"text-primary underline x1i10hfl xjbqb8w x1ejq31n x18oe1m7 x1sy0etr xstzfhl x972fbf x10w94by x1qhh985 x14e42zd x9f619 x1ypdohk xt0psk2 x3ct3a4 xdj266r x14z9mp xat24cr x1lziwak xexx8yu xyri2b x18d9i69 x1c1uobl x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xkrqix3 x1sur9pj x1fey0fg x1s688f\" href=\"https://www.facebook.com/hashtag/%E0%B8%9B%E0%B8%B1%E0%B9%8A%E0%B8%A1%E0%B8%99%E0%B9%89%E0%B8%B3%E0%B8%A1%E0%B8%B1%E0%B8%99?__eep__=6&amp;__cft__[0]=AZaBVtN_fk-53uWSIi78PJqfuz7MnjQRF8sETRVnJpNBlmSpcVmMPid0y81OUaEPMpeer9iqjq9fTyoEvyMvflFYn7Y_tkcKLhIJOiI_Ll4rdyXejJYrsrddNf-rEjBU9mE8h9w0cbTre2CVdW6WDkJRE7N8rPPIbVZNw5I5SEP9rrDI7cmhRiVLm-GsHkqyVH0&amp;__tn__=*NK-R\"><strong>#ปั๊มน้ำมัน</strong></a> <a target=\"_blank\" rel=\"noopener noreferrer nofollow\" class=\"text-primary underline x1i10hfl xjbqb8w x1ejq31n x18oe1m7 x1sy0etr xstzfhl x972fbf x10w94by x1qhh985 x14e42zd x9f619 x1ypdohk xt0psk2 x3ct3a4 xdj266r x14z9mp xat24cr x1lziwak xexx8yu xyri2b x18d9i69 x1c1uobl x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xkrqix3 x1sur9pj x1fey0fg x1s688f\" href=\"https://www.facebook.com/hashtag/%E0%B8%AD%E0%B8%B8%E0%B8%9B%E0%B8%81%E0%B8%A3%E0%B8%93%E0%B9%8C%E0%B8%9B%E0%B8%B1%E0%B9%8A%E0%B8%A1%E0%B8%99%E0%B9%89%E0%B8%B3%E0%B8%A1%E0%B8%B1%E0%B8%99?__eep__=6&amp;__cft__[0]=AZaBVtN_fk-53uWSIi78PJqfuz7MnjQRF8sETRVnJpNBlmSpcVmMPid0y81OUaEPMpeer9iqjq9fTyoEvyMvflFYn7Y_tkcKLhIJOiI_Ll4rdyXejJYrsrddNf-rEjBU9mE8h9w0cbTre2CVdW6WDkJRE7N8rPPIbVZNw5I5SEP9rrDI7cmhRiVLm-GsHkqyVH0&amp;__tn__=*NK-R\"><strong>#อุปกรณ์ปั๊มน้ำมัน</strong></a> <a target=\"_blank\" rel=\"noopener noreferrer nofollow\" class=\"text-primary underline x1i10hfl xjbqb8w x1ejq31n x18oe1m7 x1sy0etr xstzfhl x972fbf x10w94by x1qhh985 x14e42zd x9f619 x1ypdohk xt0psk2 x3ct3a4 xdj266r x14z9mp xat24cr x1lziwak xexx8yu xyri2b x18d9i69 x1c1uobl x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xkrqix3 x1sur9pj x1fey0fg x1s688f\" href=\"https://www.facebook.com/hashtag/%E0%B8%9A%E0%B8%A3%E0%B8%B4%E0%B8%AB%E0%B8%B2%E0%B8%A3%E0%B8%9B%E0%B8%B1%E0%B9%8A%E0%B8%A1%E0%B8%99%E0%B9%89%E0%B8%B3%E0%B8%A1%E0%B8%B1%E0%B8%99?__eep__=6&amp;__cft__[0]=AZaBVtN_fk-53uWSIi78PJqfuz7MnjQRF8sETRVnJpNBlmSpcVmMPid0y81OUaEPMpeer9iqjq9fTyoEvyMvflFYn7Y_tkcKLhIJOiI_Ll4rdyXejJYrsrddNf-rEjBU9mE8h9w0cbTre2CVdW6WDkJRE7N8rPPIbVZNw5I5SEP9rrDI7cmhRiVLm-GsHkqyVH0&amp;__tn__=*NK-R\"><strong>#บริหารปั๊มน้ำมัน</strong></a> <a target=\"_blank\" rel=\"noopener noreferrer nofollow\" class=\"text-primary underline x1i10hfl xjbqb8w x1ejq31n x18oe1m7 x1sy0etr xstzfhl x972fbf x10w94by x1qhh985 x14e42zd x9f619 x1ypdohk xt0psk2 x3ct3a4 xdj266r x14z9mp xat24cr x1lziwak xexx8yu xyri2b x18d9i69 x1c1uobl x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xkrqix3 x1sur9pj x1fey0fg x1s688f\" href=\"https://www.facebook.com/hashtag/ttmbtech?__eep__=6&amp;__cft__[0]=AZaBVtN_fk-53uWSIi78PJqfuz7MnjQRF8sETRVnJpNBlmSpcVmMPid0y81OUaEPMpeer9iqjq9fTyoEvyMvflFYn7Y_tkcKLhIJOiI_Ll4rdyXejJYrsrddNf-rEjBU9mE8h9w0cbTre2CVdW6WDkJRE7N8rPPIbVZNw5I5SEP9rrDI7cmhRiVLm-GsHkqyVH0&amp;__tn__=*NK-R\"><strong>#TRSServiceSolution</strong></a></p>'),('cmnfov2r1000ankt0rn6t09hu','ERP - ซอฟต์แวร์บริหารทรัพยากรองค์กร','erp-application','ERP (Enterprise Resource Planning)  เป็นระบบที่เชื่อมโยงระบบงานฝ่ายต่างๆ ขององค์กรเข้าด้วยกัน','Smartphone','[\"Work Center Management\", \"Quality Inspection\", \"Production Planning\", \"Lot Tracking\", \"ระบบจัดซื้อ Purchasing & Supplier Management\", \"ระบบฝ่ายขาย Sales & CRM\", \"ระบบบัญชี Accounting & Finance\", \"ระบบควบคุมผู้ใช้งานจำกัดสิทธิและอื่นๆครบฟังก์ชั่น\"]',2,1,'2026-04-01 06:52:37.166','2026-04-02 07:57:09.467','/uploads/37db2ff6-f06f-4d10-b280-a8535455fca9.jpg','<p>เพิ่มประสิทธิภาพโรงงานของคุณด้วยระบบวางแผนการผลิต (Manufacturing ERP) ที่ทันสมัยที่สุด!</p><p>TioERP - Manufacturing ERP System</p><p>ควบคุมทุกขั้นตอนการผลิตให้เป็นเรื่องง่าย ตั้งแต่การจัดการวัตถุดิบ (BOM) ไปจนถึงการส่งมอบสินค้า</p><ul><li><p>Work Center Management: จัดการกำลังการผลิตและคำนวณต้นทุนแรงงาน/เครื่องจักรต่อชั่วโมง </p></li></ul><ul><li><p>Quality Inspection: ระบบตรวจสอบคุณภาพ (QC) ทุกขั้นตอน เพื่อความมั่นใจก่อนถึงมือลูกค้า </p></li></ul><ul><li><p>Production Planning: วางแผนการผลิตให้สอดคล้องกับคำสั่งซื้อ (Sales Orders) ลดปัญหาของค้างสต็อก </p></li></ul><ul><li><p>Lot Tracking: ติดตามสินค้าตามล็อตผลิตและวันหมดอายุได้อย่างแม่นยำ</p></li></ul><ul><li><p>ระบบจัดซื้อ Purchasing &amp; Supplier Management</p></li></ul><ul><li><p>ระบบฝ่ายขาย Sales &amp; CRM (Customer Relationship Management)</p></li></ul><ul><li><p>ระบบบัญชี Accounting &amp; Finance</p></li></ul><ul><li><p>ระบบควบคุมผู้ใช้งานจำกัดสิทธิและอื่นๆครบฟังก์ชั่น</p></li></ul><p>เปลี่ยนโรงงานแบบเดิม ให้เป็น Smart Factory ด้วยเทคโนโลยีที่ออกแบบมาเพื่อคุณโดยเฉพาะ</p><img src=\"/uploads/67431809-c5fe-4d49-9a32-755b6355020e.jpg\"><p>สนใจติดตั้งหรือสอบถามข้อมูลเพิ่มเติม:</p><p>ทัก Inbox แชทเพจได้เลยครับ</p><p>Line : trs-solutions</p><p>เว็บไซต์: <a target=\"_blank\" rel=\"noopener noreferrer nofollow\" class=\"text-primary underline\" href=\"https://ttmb-tech.com\"><span><strong>https://trs-nextgen.com</strong></span></a></p><p>ลูกค้าท่านใดต้องการดู Demo สามารถทักมาสอบถามได้</p><p>เรามีบริการมากมาย เช่น ระบบตรวจวัดระดับน้ำมัน ( ATG ) , และออกแบบระบบเพิ่มเติมอื่นๆตามความต้องการลูกค้าได้ครับ</p><p><a target=\"_blank\" rel=\"noopener noreferrer nofollow\" class=\"text-primary underline x1i10hfl xjbqb8w x1ejq31n x18oe1m7 x1sy0etr xstzfhl x972fbf x10w94by x1qhh985 x14e42zd x9f619 x1ypdohk xt0psk2 x3ct3a4 xdj266r x14z9mp xat24cr x1lziwak xexx8yu xyri2b x18d9i69 x1c1uobl x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xkrqix3 x1sur9pj x1fey0fg x1s688f\" href=\"https://www.facebook.com/hashtag/manufacturingerp?__eep__=6&amp;__cft__[0]=AZZjHfKIFYGtfwEij4Yi8i4Zk0XNyCRDA49gEF9GFWX4jZMMDTsjPRzYHbyTBucix5Rnoq7dfsDQcUOiyoj7m-S1MkjoGpcjwOlHLXiT0bb0rcGp4GZynk27K7vUVSlVT6wrRr1I_cQ0dyBiWKpm0IZGpKQXHS-W2F2HhD4VsxuF2nDUDZK9QNxJ05dRyNjEsqI&amp;__tn__=*NK-R\"><span><strong>#ManufacturingERP</strong></span></a> <a target=\"_blank\" rel=\"noopener noreferrer nofollow\" class=\"text-primary underline x1i10hfl xjbqb8w x1ejq31n x18oe1m7 x1sy0etr xstzfhl x972fbf x10w94by x1qhh985 x14e42zd x9f619 x1ypdohk xt0psk2 x3ct3a4 xdj266r x14z9mp xat24cr x1lziwak xexx8yu xyri2b x18d9i69 x1c1uobl x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xkrqix3 x1sur9pj x1fey0fg x1s688f\" href=\"https://www.facebook.com/hashtag/smartfactory?__eep__=6&amp;__cft__[0]=AZZjHfKIFYGtfwEij4Yi8i4Zk0XNyCRDA49gEF9GFWX4jZMMDTsjPRzYHbyTBucix5Rnoq7dfsDQcUOiyoj7m-S1MkjoGpcjwOlHLXiT0bb0rcGp4GZynk27K7vUVSlVT6wrRr1I_cQ0dyBiWKpm0IZGpKQXHS-W2F2HhD4VsxuF2nDUDZK9QNxJ05dRyNjEsqI&amp;__tn__=*NK-R\"><span><strong>#SmartFactory</strong></span></a> <a target=\"_blank\" rel=\"noopener noreferrer nofollow\" class=\"text-primary underline x1i10hfl xjbqb8w x1ejq31n x18oe1m7 x1sy0etr xstzfhl x972fbf x10w94by x1qhh985 x14e42zd x9f619 x1ypdohk xt0psk2 x3ct3a4 xdj266r x14z9mp xat24cr x1lziwak xexx8yu xyri2b x18d9i69 x1c1uobl x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xkrqix3 x1sur9pj x1fey0fg x1s688f\" href=\"https://www.facebook.com/hashtag/supplychain?__eep__=6&amp;__cft__[0]=AZZjHfKIFYGtfwEij4Yi8i4Zk0XNyCRDA49gEF9GFWX4jZMMDTsjPRzYHbyTBucix5Rnoq7dfsDQcUOiyoj7m-S1MkjoGpcjwOlHLXiT0bb0rcGp4GZynk27K7vUVSlVT6wrRr1I_cQ0dyBiWKpm0IZGpKQXHS-W2F2HhD4VsxuF2nDUDZK9QNxJ05dRyNjEsqI&amp;__tn__=*NK-R\"><span><strong>#SupplyChain</strong></span></a> <a target=\"_blank\" rel=\"noopener noreferrer nofollow\" class=\"text-primary underline x1i10hfl xjbqb8w x1ejq31n x18oe1m7 x1sy0etr xstzfhl x972fbf x10w94by x1qhh985 x14e42zd x9f619 x1ypdohk xt0psk2 x3ct3a4 xdj266r x14z9mp xat24cr x1lziwak xexx8yu xyri2b x18d9i69 x1c1uobl x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xkrqix3 x1sur9pj x1fey0fg x1s688f\" href=\"https://www.facebook.com/hashtag/productionplanning?__eep__=6&amp;__cft__[0]=AZZjHfKIFYGtfwEij4Yi8i4Zk0XNyCRDA49gEF9GFWX4jZMMDTsjPRzYHbyTBucix5Rnoq7dfsDQcUOiyoj7m-S1MkjoGpcjwOlHLXiT0bb0rcGp4GZynk27K7vUVSlVT6wrRr1I_cQ0dyBiWKpm0IZGpKQXHS-W2F2HhD4VsxuF2nDUDZK9QNxJ05dRyNjEsqI&amp;__tn__=*NK-R\"><span><strong>#ProductionPlanning</strong></span></a> <a target=\"_blank\" rel=\"noopener noreferrer nofollow\" class=\"text-primary underline x1i10hfl xjbqb8w x1ejq31n x18oe1m7 x1sy0etr xstzfhl x972fbf x10w94by x1qhh985 x14e42zd x9f619 x1ypdohk xt0psk2 x3ct3a4 xdj266r x14z9mp xat24cr x1lziwak xexx8yu xyri2b x18d9i69 x1c1uobl x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xkrqix3 x1sur9pj x1fey0fg x1s688f\" href=\"https://www.facebook.com/hashtag/factorymanagement?__eep__=6&amp;__cft__[0]=AZZjHfKIFYGtfwEij4Yi8i4Zk0XNyCRDA49gEF9GFWX4jZMMDTsjPRzYHbyTBucix5Rnoq7dfsDQcUOiyoj7m-S1MkjoGpcjwOlHLXiT0bb0rcGp4GZynk27K7vUVSlVT6wrRr1I_cQ0dyBiWKpm0IZGpKQXHS-W2F2HhD4VsxuF2nDUDZK9QNxJ05dRyNjEsqI&amp;__tn__=*NK-R\"><span><strong>#FactoryManagement</strong></span></a></p>'),('cmnfov2r4000bnkt04tcvm12j','บริการ IT Infrastructure','it-infrastructure','ให้คำปรึกษา ออกแบบ ติดตั้ง และดูแลรักษาโครงสร้างพื้นฐานระบบไอทีครบวงจร ครอบคลุมระบบเซิร์ฟเวอร์, เครือข่าย (Network), Data Center, ระบบจัดเก็บข้อมูล (Storage) และความปลอดภัยทางไซเบอร์ เพื่อเพิ่มประสิทธิภาพองค์กร ความต่อเนื่องของธุรกิจ และลดความเสี่ยงข้อมูลสูญหาย','Cloud','[\"AWS & Azure\", \"CI/CD Pipelines\", \"Microservices\", \"Auto-scaling\"]',3,1,'2026-04-01 06:52:37.169','2026-04-05 15:11:22.101','/uploads/d2d3e873-93dc-467e-9a4f-67746570d156.png','<img src=\"/uploads/dc7dbfb3-50bb-4399-9778-278023908eeb.png\"><p><strong>บริการหลักด้าน IT Infrastructure ที่สำคัญ</strong></p><ul><li><p><span><strong>ออกแบบและวางระบบ Network:</strong> ติดตั้ง Router, Switch, Wi-Fi และระบบเครือข่ายภายในองค์กร</span></p></li><li><p><span><strong>ระบบ Server &amp; Data Center:</strong> วางระบบเซิร์ฟเวอร์, จัดทำห้อง Data Center, และระบบ Virtualization (VM) เพื่อประหยัดฮาร์ดแวร์</span></p></li><li><p><span><strong>ระบบรักษาความปลอดภัย (IT Security):</strong> ติดตั้ง Firewall, ระบบป้องกันเครือข่าย และตรวจสอบช่องโหว่</span></p></li><li><p><span><strong>ระบบจัดเก็บและสำรองข้อมูล (Backup &amp; Storage):</strong> จัดการ NAS, SAN และระบบสำรองข้อมูลอัตโนมัติ (DRaaS) เพื่อป้องกันข้อมูลสูญหาย</span></p></li><li><p><span><strong>บริการ Managed IT Services:</strong> ดูแลระบบรายเดือน (Onsite/Remote) โดยผู้เชี่ยวชาญ</span></p></li></ul><p><strong>ประโยชน์ของการใช้บริการ IT Infrastructure</strong></p><ul><li><p><span><strong>เพิ่มเสถียรภาพ:</strong> ระบบทำงานได้ต่อเนื่อง ลดความเสี่ยงระบบล่ม (Downtime)</span></p></li><li><p><span><strong>ความปลอดภัยสูง:</strong> ป้องกันภัยคุกคามทางไซเบอร์ที่ซับซ้อนได้ดียิ่งขึ้น</span></p></li><li><p><span><strong>ประหยัดค่าใช้จ่าย:</strong> ลดการลงทุนฮาร์ดแวร์ระยะยาวและเปลี่ยนมาใช้ระบบเช่า (IaaS/Cloud) ได้</span></p></li><li><p><span><strong>รองรับการขยายตัว:</strong> ออกแบบให้พร้อมรองรับการเติบโตของธุรกิจในอนาคต</span></p></li></ul>'),('cmnfov2r7000cnkt0vnboutt5','บริการรับเขียนโปรแกรมและพัฒนาซอฟต์แวร์ครบวงจร','software','บริการรับเขียนโปรแกรมและพัฒนาซอฟต์แวร์ครบวงจร โดยทีมงานมืออาชีพ ครอบคลุม Web Application, Mobile App (iOS/Android), ระบบหลังบ้าน (Backend), และ IoT ตามความต้องการของธุรกิจ เน้นพัฒนาซอฟต์แวร์คุณภาพสูงเพื่อเพิ่มประสิทธิภาพการทำงานและแก้ปัญหาเฉพาะด้าน','TrendingUp','[\"SEO Optimization\", \"Content Strategy\", \"Social Media\", \"Analytics & Reporting\"]',4,1,'2026-04-01 06:52:37.171','2026-04-05 15:18:12.321','/uploads/12096348-30f8-4cad-9b89-2e04a683c3a8.jpg','<img src=\"/uploads/f16a965d-fd5b-4d41-adff-8d9b542ad838.jpg\"><p><strong>บริการหลักที่ครอบคลุม:</strong></p><ul><li><p><span><strong>[</strong></span><a target=\"_blank\" rel=\"noopener noreferrer nofollow\" class=\"text-primary underline GI370e\" href=\"https://www.google.com/search?q=%E0%B8%A3%E0%B8%B1%E0%B8%9A%E0%B8%9E%E0%B8%B1%E0%B8%92%E0%B8%99%E0%B8%B2+Web+Application&amp;sca_esv=961d7d2aee6e1575&amp;biw=1528&amp;bih=828&amp;sxsrf=ANbL-n7_xWUGOFOufyUMHRCdfxfahuZkXA%3A1775402038680&amp;ei=NnzSaYyNKYu_vr0Pu73D8As&amp;oq=%E0%B8%9A%E0%B8%A3%E0%B8%B4%E0%B8%81%E0%B8%B2%E0%B8%A3+%E0%B8%94%E0%B8%82%E0%B8%B5%E0%B8%A2%E0%B8%99%E0%B9%82&amp;gs_lp=Egxnd3Mtd2l6LXNlcnAiJeC4muC4o-C4tOC4geC4suC4oyDguJTguILguLXguKLguJnguYIqAggAMgcQIRigARgKMgcQIRigARgKMgcQIRigARgKSItMUPILWPxEcAN4AZABAJgB_wGgAZ8RqgEFNC45LjK4AQPIAQD4AQGYAg-gAtQNwgIKEAAYsAMY1gQYR8ICBhAAGBYYHsICBhAAGA0YHsICBBAjGCfCAgUQABiABMICChAjGPAFGCcYyQLCAgUQIRigAcICBxAAGIAEGA3CAggQABgKGA0YHsICCBAAGAUYDRgewgIFEAAY7wXCAggQABiABBiiBJgDAIgGAZAGCJIHBTcuNi4yoAeGYrIHBTQuNi4yuAfMDcIHBjAuMTQuMcgHH4AIAA&amp;sclient=gws-wiz-serp&amp;mstk=AUtExfDDIYNdZT6zomQQB9apt8s3XpvDti1MInHJSvRgWbQI9_KKgI0r8y7ADGtlAsV8zrqWM1jfTw71wTcZ7uh_J9JvLirdkVrMPu3KMCG-01Fbl6Pr8u3vv4mtm2uj7EBOGQCGBVxCO6Lcs5-Aw6GU6RVZHEf7LA11Pl6gU2Q4OMkosYxvLD3iteNEknA4UC69CfMM699LTLFpclf4vUnpOmEeMLY6GKNZ7mUY7qaUP_DTx2iYO-mXN0O9bFCTpZX3BUW-RiETKFaqvng9IhjbzgVmXsrbC77Dv9JHwQHn1S4ca9jEN62EmWA8JWbgEXCXlA&amp;csui=3&amp;ved=2ahUKEwiL18SFgNeTAxUDdvUHHTUSER4QgK4QegQIAxAB\"><span><strong><u>รับพัฒนา Web Application</u></strong></span></a><span><strong>]</strong> และเว็บไซต์ตามความต้องการ (Custom Web Development)</span></p></li><li><p><span><strong>[</strong></span><a target=\"_blank\" rel=\"noopener noreferrer nofollow\" class=\"text-primary underline GI370e\" href=\"https://www.google.com/search?q=%E0%B8%A3%E0%B8%B1%E0%B8%9A%E0%B9%80%E0%B8%82%E0%B8%B5%E0%B8%A2%E0%B8%99+Mobile+Application&amp;sca_esv=961d7d2aee6e1575&amp;biw=1528&amp;bih=828&amp;sxsrf=ANbL-n7_xWUGOFOufyUMHRCdfxfahuZkXA%3A1775402038680&amp;ei=NnzSaYyNKYu_vr0Pu73D8As&amp;oq=%E0%B8%9A%E0%B8%A3%E0%B8%B4%E0%B8%81%E0%B8%B2%E0%B8%A3+%E0%B8%94%E0%B8%82%E0%B8%B5%E0%B8%A2%E0%B8%99%E0%B9%82&amp;gs_lp=Egxnd3Mtd2l6LXNlcnAiJeC4muC4o-C4tOC4geC4suC4oyDguJTguILguLXguKLguJnguYIqAggAMgcQIRigARgKMgcQIRigARgKMgcQIRigARgKSItMUPILWPxEcAN4AZABAJgB_wGgAZ8RqgEFNC45LjK4AQPIAQD4AQGYAg-gAtQNwgIKEAAYsAMY1gQYR8ICBhAAGBYYHsICBhAAGA0YHsICBBAjGCfCAgUQABiABMICChAjGPAFGCcYyQLCAgUQIRigAcICBxAAGIAEGA3CAggQABgKGA0YHsICCBAAGAUYDRgewgIFEAAY7wXCAggQABiABBiiBJgDAIgGAZAGCJIHBTcuNi4yoAeGYrIHBTQuNi4yuAfMDcIHBjAuMTQuMcgHH4AIAA&amp;sclient=gws-wiz-serp&amp;mstk=AUtExfDDIYNdZT6zomQQB9apt8s3XpvDti1MInHJSvRgWbQI9_KKgI0r8y7ADGtlAsV8zrqWM1jfTw71wTcZ7uh_J9JvLirdkVrMPu3KMCG-01Fbl6Pr8u3vv4mtm2uj7EBOGQCGBVxCO6Lcs5-Aw6GU6RVZHEf7LA11Pl6gU2Q4OMkosYxvLD3iteNEknA4UC69CfMM699LTLFpclf4vUnpOmEeMLY6GKNZ7mUY7qaUP_DTx2iYO-mXN0O9bFCTpZX3BUW-RiETKFaqvng9IhjbzgVmXsrbC77Dv9JHwQHn1S4ca9jEN62EmWA8JWbgEXCXlA&amp;csui=3&amp;ved=2ahUKEwiL18SFgNeTAxUDdvUHHTUSER4QgK4QegQIAxAD\"><span><strong><u>รับเขียน Mobile Application</u></strong></span></a><span><strong>]</strong> ทั้ง iOS และ Android ด้วย Flutter, React Native</span></p></li><li><p><span><strong>[</strong></span><a target=\"_blank\" rel=\"noopener noreferrer nofollow\" class=\"text-primary underline GI370e\" href=\"https://www.google.com/search?q=%E0%B8%9E%E0%B8%B1%E0%B8%92%E0%B8%99%E0%B8%B2%E0%B8%A3%E0%B8%B0%E0%B8%9A%E0%B8%9A%E0%B8%9A%E0%B8%A3%E0%B8%B4%E0%B8%AB%E0%B8%B2%E0%B8%A3%E0%B8%88%E0%B8%B1%E0%B8%94%E0%B8%81%E0%B8%B2%E0%B8%A3%E0%B8%A0%E0%B8%B2%E0%B8%A2%E0%B9%83%E0%B8%99&amp;sca_esv=961d7d2aee6e1575&amp;biw=1528&amp;bih=828&amp;sxsrf=ANbL-n7_xWUGOFOufyUMHRCdfxfahuZkXA%3A1775402038680&amp;ei=NnzSaYyNKYu_vr0Pu73D8As&amp;oq=%E0%B8%9A%E0%B8%A3%E0%B8%B4%E0%B8%81%E0%B8%B2%E0%B8%A3+%E0%B8%94%E0%B8%82%E0%B8%B5%E0%B8%A2%E0%B8%99%E0%B9%82&amp;gs_lp=Egxnd3Mtd2l6LXNlcnAiJeC4muC4o-C4tOC4geC4suC4oyDguJTguILguLXguKLguJnguYIqAggAMgcQIRigARgKMgcQIRigARgKMgcQIRigARgKSItMUPILWPxEcAN4AZABAJgB_wGgAZ8RqgEFNC45LjK4AQPIAQD4AQGYAg-gAtQNwgIKEAAYsAMY1gQYR8ICBhAAGBYYHsICBhAAGA0YHsICBBAjGCfCAgUQABiABMICChAjGPAFGCcYyQLCAgUQIRigAcICBxAAGIAEGA3CAggQABgKGA0YHsICCBAAGAUYDRgewgIFEAAY7wXCAggQABiABBiiBJgDAIgGAZAGCJIHBTcuNi4yoAeGYrIHBTQuNi4yuAfMDcIHBjAuMTQuMcgHH4AIAA&amp;sclient=gws-wiz-serp&amp;mstk=AUtExfDDIYNdZT6zomQQB9apt8s3XpvDti1MInHJSvRgWbQI9_KKgI0r8y7ADGtlAsV8zrqWM1jfTw71wTcZ7uh_J9JvLirdkVrMPu3KMCG-01Fbl6Pr8u3vv4mtm2uj7EBOGQCGBVxCO6Lcs5-Aw6GU6RVZHEf7LA11Pl6gU2Q4OMkosYxvLD3iteNEknA4UC69CfMM699LTLFpclf4vUnpOmEeMLY6GKNZ7mUY7qaUP_DTx2iYO-mXN0O9bFCTpZX3BUW-RiETKFaqvng9IhjbzgVmXsrbC77Dv9JHwQHn1S4ca9jEN62EmWA8JWbgEXCXlA&amp;csui=3&amp;ved=2ahUKEwiL18SFgNeTAxUDdvUHHTUSER4QgK4QegQIAxAF\"><span><strong><u>พัฒนาระบบบริหารจัดการภายใน</u></strong></span></a><span><strong>]</strong> (ERP, CRM, POS, ระบบคิว)</span></p></li><li><p><span><strong>[</strong></span><a target=\"_blank\" rel=\"noopener noreferrer nofollow\" class=\"text-primary underline GI370e\" href=\"https://www.google.com/search?q=%E0%B8%9A%E0%B8%A3%E0%B8%B4%E0%B8%81%E0%B8%B2%E0%B8%A3%E0%B9%80%E0%B8%82%E0%B8%B5%E0%B8%A2%E0%B8%99%E0%B9%82%E0%B8%9B%E0%B8%A3%E0%B9%81%E0%B8%81%E0%B8%A3%E0%B8%A1%E0%B9%80%E0%B8%89%E0%B8%9E%E0%B8%B2%E0%B8%B0%E0%B8%97%E0%B8%B2%E0%B8%87&amp;sca_esv=961d7d2aee6e1575&amp;biw=1528&amp;bih=828&amp;sxsrf=ANbL-n7_xWUGOFOufyUMHRCdfxfahuZkXA%3A1775402038680&amp;ei=NnzSaYyNKYu_vr0Pu73D8As&amp;oq=%E0%B8%9A%E0%B8%A3%E0%B8%B4%E0%B8%81%E0%B8%B2%E0%B8%A3+%E0%B8%94%E0%B8%82%E0%B8%B5%E0%B8%A2%E0%B8%99%E0%B9%82&amp;gs_lp=Egxnd3Mtd2l6LXNlcnAiJeC4muC4o-C4tOC4geC4suC4oyDguJTguILguLXguKLguJnguYIqAggAMgcQIRigARgKMgcQIRigARgKMgcQIRigARgKSItMUPILWPxEcAN4AZABAJgB_wGgAZ8RqgEFNC45LjK4AQPIAQD4AQGYAg-gAtQNwgIKEAAYsAMY1gQYR8ICBhAAGBYYHsICBhAAGA0YHsICBBAjGCfCAgUQABiABMICChAjGPAFGCcYyQLCAgUQIRigAcICBxAAGIAEGA3CAggQABgKGA0YHsICCBAAGAUYDRgewgIFEAAY7wXCAggQABiABBiiBJgDAIgGAZAGCJIHBTcuNi4yoAeGYrIHBTQuNi4yuAfMDcIHBjAuMTQuMcgHH4AIAA&amp;sclient=gws-wiz-serp&amp;mstk=AUtExfDDIYNdZT6zomQQB9apt8s3XpvDti1MInHJSvRgWbQI9_KKgI0r8y7ADGtlAsV8zrqWM1jfTw71wTcZ7uh_J9JvLirdkVrMPu3KMCG-01Fbl6Pr8u3vv4mtm2uj7EBOGQCGBVxCO6Lcs5-Aw6GU6RVZHEf7LA11Pl6gU2Q4OMkosYxvLD3iteNEknA4UC69CfMM699LTLFpclf4vUnpOmEeMLY6GKNZ7mUY7qaUP_DTx2iYO-mXN0O9bFCTpZX3BUW-RiETKFaqvng9IhjbzgVmXsrbC77Dv9JHwQHn1S4ca9jEN62EmWA8JWbgEXCXlA&amp;csui=3&amp;ved=2ahUKEwiL18SFgNeTAxUDdvUHHTUSER4QgK4QegQIAxAH\"><span><strong><u>บริการเขียนโปรแกรมเฉพาะทาง</u></strong></span></a><span><strong>]</strong> เช่น PLC, IoT, ระบบควบคุมเครื่องจักร</span></p></li><li><p><span><strong>[</strong></span><a target=\"_blank\" rel=\"noopener noreferrer nofollow\" class=\"text-primary underline GI370e\" href=\"https://www.google.com/search?q=%E0%B9%83%E0%B8%AB%E0%B9%89%E0%B8%84%E0%B8%B3%E0%B8%9B%E0%B8%A3%E0%B8%B6%E0%B8%81%E0%B8%A9%E0%B8%B2%E0%B8%94%E0%B9%89%E0%B8%B2%E0%B8%99%E0%B9%84%E0%B8%AD%E0%B8%97%E0%B8%B5+%28IT+Consultant%29&amp;sca_esv=961d7d2aee6e1575&amp;biw=1528&amp;bih=828&amp;sxsrf=ANbL-n7_xWUGOFOufyUMHRCdfxfahuZkXA%3A1775402038680&amp;ei=NnzSaYyNKYu_vr0Pu73D8As&amp;oq=%E0%B8%9A%E0%B8%A3%E0%B8%B4%E0%B8%81%E0%B8%B2%E0%B8%A3+%E0%B8%94%E0%B8%82%E0%B8%B5%E0%B8%A2%E0%B8%99%E0%B9%82&amp;gs_lp=Egxnd3Mtd2l6LXNlcnAiJeC4muC4o-C4tOC4geC4suC4oyDguJTguILguLXguKLguJnguYIqAggAMgcQIRigARgKMgcQIRigARgKMgcQIRigARgKSItMUPILWPxEcAN4AZABAJgB_wGgAZ8RqgEFNC45LjK4AQPIAQD4AQGYAg-gAtQNwgIKEAAYsAMY1gQYR8ICBhAAGBYYHsICBhAAGA0YHsICBBAjGCfCAgUQABiABMICChAjGPAFGCcYyQLCAgUQIRigAcICBxAAGIAEGA3CAggQABgKGA0YHsICCBAAGAUYDRgewgIFEAAY7wXCAggQABiABBiiBJgDAIgGAZAGCJIHBTcuNi4yoAeGYrIHBTQuNi4yuAfMDcIHBjAuMTQuMcgHH4AIAA&amp;sclient=gws-wiz-serp&amp;mstk=AUtExfDDIYNdZT6zomQQB9apt8s3XpvDti1MInHJSvRgWbQI9_KKgI0r8y7ADGtlAsV8zrqWM1jfTw71wTcZ7uh_J9JvLirdkVrMPu3KMCG-01Fbl6Pr8u3vv4mtm2uj7EBOGQCGBVxCO6Lcs5-Aw6GU6RVZHEf7LA11Pl6gU2Q4OMkosYxvLD3iteNEknA4UC69CfMM699LTLFpclf4vUnpOmEeMLY6GKNZ7mUY7qaUP_DTx2iYO-mXN0O9bFCTpZX3BUW-RiETKFaqvng9IhjbzgVmXsrbC77Dv9JHwQHn1S4ca9jEN62EmWA8JWbgEXCXlA&amp;csui=3&amp;ved=2ahUKEwiL18SFgNeTAxUDdvUHHTUSER4QgK4QegQIAxAJ\"><span><strong><u>ให้คำปรึกษาด้านไอที (IT Consultant)</u></strong></span></a><span><strong>]</strong> และออกแบบ UX/UI</span></p><p></p><p><strong>ขั้นตอนการดำเนินงานทั่วไป:</strong></p><ol><li><p><span><strong>ประเมินความต้องการ:</strong> รวบรวมข้อมูลและขอบเขตงาน</span></p></li><li><p><span><strong>ออกแบบและพัฒนา:</strong> วางโครงสร้างและเขียนโค้ด</span></p></li><li><p><span><strong>ทดสอบและติดตั้ง:</strong> ทดสอบการทำงาน ติดตั้งจริง และสอนการใช้งาน</span></p></li></ol></li></ul>'),('cmnfov2r9000dnkt0lmgcz9et','Tech Consulting','consulting','บริการให้คำปรึกษา ออกแบบ วางแผน และดำเนินงานด้านไอที เพื่อให้องค์กรสามารถใช้เทคโนโลยีขับเคลื่อนธุรกิจได้อย่างมีประสิทธิภาพ ครอบคลุมตั้งแต่ Digital Transformation, Cybersecurity จนถึงการใช้ AI และ Cloud เพื่อเพิ่มความได้เปรียบในการแข่งขัน','Lightbulb','[\"Technology Strategy\", \"Architecture Review\", \"Digital Transformation\", \"Team Training\"]',5,1,'2026-04-01 06:52:37.174','2026-04-05 15:13:38.756','/uploads/7d8f335b-82c5-4ccf-b818-b845824479c6.jpg','<img src=\"/uploads/fc6e1b45-488e-4d39-8509-ad83f1a21e27.jpg\"><p><strong>ขอบเขตและบริการหลักของ Tech Consulting</strong></p><ul><li><p><span><strong>วางแผนกลยุทธ์ IT (IT Strategy &amp; Planning):</strong> ปรับโครงสร้างเทคโนโลยีให้สอดคล้องกับเป้าหมายทางธุรกิจ</span></p></li><li><p><span><strong>การออกแบบระบบและสถาปัตยกรรม (System Architecture):</strong> ออกแบบระบบโครงสร้างพื้นฐาน, แอปพลิเคชัน, และข้อมูล</span></p></li><li><p><span><strong>ความปลอดภัยทางไซเบอร์ (Cybersecurity):</strong> ให้คำปรึกษาด้านความปลอดภัย, มาตรฐาน ISO, และ </span><a target=\"_blank\" rel=\"noopener noreferrer nofollow\" class=\"text-primary underline GI370e\" href=\"https://www.google.com/search?q=IT+Governance&amp;sca_esv=961d7d2aee6e1575&amp;biw=1528&amp;bih=828&amp;sxsrf=ANbL-n4DFp70MLFMgf0f12htgECnS4_mOw%3A1775401835096&amp;ei=a3vSaebHBa_f2roPmJzX2QM&amp;ved=2ahUKEwjRmO-__9aTAxWmp1YBHfb2KeIQgK4QegQIAxAD&amp;uact=5&amp;oq=%E0%B8%9A%E0%B8%A3%E0%B8%B4%E0%B8%81%E0%B8%B2%E0%B8%A3+Tech+Consulting&amp;gs_lp=Egxnd3Mtd2l6LXNlcnAiIuC4muC4o-C4tOC4geC4suC4oyBUZWNoIENvbnN1bHRpbmcyBRAhGKABSPsOUPgGWNoIcAJ4AZABAJgBtwGgAcECqgEDMC4yuAEDyAEA-AEB-AECmAIEoALRAsICChAAGLADGNYEGEfCAgUQABiABJgDAIgGAZAGA5IHAzIuMqAHtAayBwMwLjK4B8kCwgcFMS4yLjHIBwiACAA&amp;sclient=gws-wiz-serp&amp;mstk=AUtExfC3DmTSPrsoSVjYb6dreVPzgNirs3xwsbAgpdlzod3i-q7iimEsihD6esQGH_qcDyuYCeqO58w3cKHhldBVZpAjTH14PekgGRSFYZtAsTbyeCKZQ2g8t26CLFrSgPjowEbz5_d6Hb8gGK4WkgaDnEwNe7enelBJ0MvTD7sXrwKUUCVWEb1IhlsdufBBdKgPwZx3acSSoq5UuP0XRC5MuahxyC3Z7X4fDcRyT_8gDu0X2rqzZYIOqCLsjDE0CjY5Ds84Aj1DTLGbCReE3iaoJjklc1d9NHimMzHoxY97X1Poqg&amp;csui=3\"><span><u>IT Governance</u></span></a></p></li><li><p><span><strong>บริการ Cloud และ IT Transformation:</strong> การปรับปรุงระบบเดิมให้ทันสมัย (Modernization) และการเปลี่ยนผ่านสู่ Cloud Computing</span></p></li><li><p><span><strong>การนำ AI มาใช้งาน (AI Implementation):</strong> ใช้ </span><a target=\"_blank\" rel=\"noopener noreferrer nofollow\" class=\"text-primary underline GI370e\" href=\"https://www.google.com/search?q=Generative+AI&amp;sca_esv=961d7d2aee6e1575&amp;biw=1528&amp;bih=828&amp;sxsrf=ANbL-n4DFp70MLFMgf0f12htgECnS4_mOw%3A1775401835096&amp;ei=a3vSaebHBa_f2roPmJzX2QM&amp;ved=2ahUKEwjRmO-__9aTAxWmp1YBHfb2KeIQgK4QegQIAxAG&amp;uact=5&amp;oq=%E0%B8%9A%E0%B8%A3%E0%B8%B4%E0%B8%81%E0%B8%B2%E0%B8%A3+Tech+Consulting&amp;gs_lp=Egxnd3Mtd2l6LXNlcnAiIuC4muC4o-C4tOC4geC4suC4oyBUZWNoIENvbnN1bHRpbmcyBRAhGKABSPsOUPgGWNoIcAJ4AZABAJgBtwGgAcECqgEDMC4yuAEDyAEA-AEB-AECmAIEoALRAsICChAAGLADGNYEGEfCAgUQABiABJgDAIgGAZAGA5IHAzIuMqAHtAayBwMwLjK4B8kCwgcFMS4yLjHIBwiACAA&amp;sclient=gws-wiz-serp&amp;mstk=AUtExfC3DmTSPrsoSVjYb6dreVPzgNirs3xwsbAgpdlzod3i-q7iimEsihD6esQGH_qcDyuYCeqO58w3cKHhldBVZpAjTH14PekgGRSFYZtAsTbyeCKZQ2g8t26CLFrSgPjowEbz5_d6Hb8gGK4WkgaDnEwNe7enelBJ0MvTD7sXrwKUUCVWEb1IhlsdufBBdKgPwZx3acSSoq5UuP0XRC5MuahxyC3Z7X4fDcRyT_8gDu0X2rqzZYIOqCLsjDE0CjY5Ds84Aj1DTLGbCReE3iaoJjklc1d9NHimMzHoxY97X1Poqg&amp;csui=3\"><span><u>Generative AI</u></span></a><span> และเครื่องมือ Low-Code เพื่อเพิ่มประสิทธิภาพการทำงาน</span></p></li></ul><p><strong>ประโยชน์ของการใช้บริการ Tech Consulting</strong></p><ul><li><p><span><strong>ความเชี่ยวชาญเฉพาะด้าน:</strong> ได้รับคำแนะนำจากผู้เชี่ยวชาญ (Specialist) ที่มีความรู้ลึกซึ้งโดยไม่ต้องจ้างทีมงานภายในเอง</span></p></li><li><p><span><strong>คุ้มค่าและปลอดภัย:</strong> ลดความเสี่ยงในการดำเนินงาน และวางแผนการใช้เทคโนโลยีที่คุ้มค่ากับงบประมาณ</span></p></li><li><p><span><strong>ทันสมัยและตอบโจทย์ธุรกิจ:</strong> ทำให้องค์กรได้รับเทคโนโลยีใหม่ๆ ที่ปรับเปลี่ยนตามความต้องการ (Personalized Solution)</span></p></li></ul><p></p><p><strong>กลุ่มเป้าหมาย:</strong> องค์กรทุกขนาดที่ต้องการปรับเปลี่ยนองค์กรสู่ยุคดิจิทัล (Digital Transformation) หรือต้องการที่ปรึกษาเพื่อยกระดับโครงสร้างพื้นฐานไอที</p>');
/*!40000 ALTER TABLE `service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session`
--

DROP TABLE IF EXISTS `session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `session` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sessionToken` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Session_sessionToken_key` (`sessionToken`),
  KEY `Session_userId_fkey` (`userId`),
  CONSTRAINT `Session_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session`
--

LOCK TABLES `session` WRITE;
/*!40000 ALTER TABLE `session` DISABLE KEYS */;
/*!40000 ALTER TABLE `session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitesetting`
--

DROP TABLE IF EXISTS `sitesetting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitesetting` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `SiteSetting_key_key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitesetting`
--

LOCK TABLES `sitesetting` WRITE;
/*!40000 ALTER TABLE `sitesetting` DISABLE KEYS */;
INSERT INTO `sitesetting` VALUES ('cmnfov2sg000qnkt0nzwk6bie','siteName','ทีอาร์เอส เซอร์วิส โซลูชั่น'),('cmnfov2sk000rnkt0fec3oe2v','siteDescription','บริการสร้างปั้มน้ำมัน ซอร์ฟแวร์ปั้มน้ำมันและออกแบบระบบไอทีครบวงจร'),('cmnfov2sm000snkt033453229','siteUrl','https://trs-nextgen.com'),('cmnfov2sq000tnkt013x0uj0v','contactEmail','admin@trs-nextgen.com'),('cmnfov2st000unkt0v51tddro','contactPhone','0983631398'),('cmnfov2sx000vnkt0qd6j52hu','address','456 หมู่ 6 ต.ศรีมหาโพธิ อ.ศรีมหาโพธิ จ.ปราจีนบุรี 25140'),('cmnfov2t0000wnkt0i3gy7cww','socialTwitter','https://twitter.com/trs-service-solution'),('cmnfov2t3000xnkt00a68oncg','socialLinkedin','https://linkedin.com/company/trs-service-solution'),('cmnfov2t7000ynkt02tj3x3am','socialGithub','https://github.com/trs-service-solution'),('cmnm0bb050000nka80isrp96y','homeHeroBadge','โซลูชันองค์กร'),('cmnm0bb060001nka89awph44n','homeHeroSubtitle','\nPOS สำหรับปั๊มน้ำมัน ตรวจสอบสต็อก และระบบ ERP — ออกแบบมาเพื่อความเสถียร การขยายตัว และการดำเนินงานจริงในทุกวัน'),('cmnm0bb060002nka850skvatc','homeHeroTitleBefore','พัฒนา'),('cmnm0bb060003nka8r93dlmq1','homeHeroTitleHighlight','ระบบครบวงจร'),('cmnm0bb060004nka8zyyo7lft','homeHeroTitleAfter','เพื่อความต้องการของคุณ'),('cmnm0bb060005nka8j1v8y10b','homeHeroPrimaryCtaText','เริ่มต้นใช้บริการ'),('cmnm0bb060006nka8ekdw3xvr','homeHeroSecondaryCtaText','ดูผลงาน'),('cmnm0bb060007nka8y5fs37yy','homeHeroImage',''),('cmnm0bb060008nka84spbir2e','homeHeroStats','[{\"value\":\"20+\",\"label\":\"โครงการ\"},{\"value\":\"จ.ปราจีนบุรี\",\"label\":\"จุดให้บริการ\"},{\"value\":\"24/7\",\"label\":\"ซัพพอร์ต\"}]'),('cmnm0bb060009nka8y00fo2kj','homeHeroUseCustomHtml','1'),('cmnm0bb06000anka8r9qricmv','homeHeroCustomHtml','');
/*!40000 ALTER TABLE `sitesetting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teammember`
--

DROP TABLE IF EXISTS `teammember`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teammember` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bio` text COLLATE utf8mb4_unicode_ci,
  `imageUrl` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `linkedin` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` int NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teammember`
--

LOCK TABLES `teammember` WRITE;
/*!40000 ALTER TABLE `teammember` DISABLE KEYS */;
INSERT INTO `teammember` VALUES ('cmnfov2rm000hnkt0e05233e6','คุณท๊อป','Founder & CEO','ผู้นำที่มีวิสัยทัศน์กว้างไกลและประสบการณ์ในการทำธุรกิจมากกว่า 15 ปี มีความมุ่งมั่นในการสร้างสรรค์โซลูชันดิจิทัลที่ล้ำสมัยเพื่อพลิกโฉมธุรกิจ','/uploads/3f395cf7-1ad5-4b72-95ff-314e0b1b5a53.png','ceo.top@trs-nextgen.com','','',0,1,'2026-04-01 06:52:37.186','2026-04-02 05:48:36.886'),('cmnfov2rp000inkt089n3075r','ต้า','Lead Developer & Manager IT & Project Manager','ช่วยให้ทุกอย่างดำเนินไปอย่างราบรื่น เชี่ยวชาญด้านวิธีการทำงานแบบ Agile และมีความสามารถในการประสานทีมให้ทำงานร่วมกันได้ดี','/uploads/f09aa969-ea6c-452a-9dae-1a699429a5a7.png','kridsadar@trs-nextgen.com','','',1,1,'2026-04-01 06:52:37.189','2026-04-02 06:27:47.335'),('cmnfov2rs000jnkt0gwyy2www','มอส','Assist Manager, Lead Maintenance','น้องมอสจะคอยประสานในส่วนต่างๆกับทีมงาน อำนวบความสะดวกและลงหน้างานจริงในการติดตั้ง ประสบการณ์เกี่ยวกับงานช่างหน้างานมากกว่า 6 ปี','/uploads/273b7f47-5b57-4c00-a2dc-846c09748c10.png','pongsathon@trs-nextgen.com','','',2,1,'2026-04-01 06:52:37.192','2026-04-02 05:54:18.680'),('cmnfov2rv000knkt0cj2oh9ps','แสตมป์','Developer','วิศวกรซอฟต์แวร์ผู้หลงใหลในโค้ดที่สะอาดตาและงานอดิเรกที่ไม่เป็นระเบียบ. เปลี่ยนกาแฟให้เป็นโค้ด สร้างสรรค์สิ่งเจ๋งๆ บนอินเทอร์เน็ต. แก้ปัญหาที่ซับซ้อนทีละบรรทัดของโค้ด ✨.','/uploads/32729972-1d1f-4068-917b-47442b266495.jpg','stamp@trs-nextgen.com','','',3,1,'2026-04-01 06:52:37.195','2026-04-02 06:33:47.532');
/*!40000 ALTER TABLE `teammember` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testimonial`
--

DROP TABLE IF EXISTS `testimonial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `testimonial` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `imageUrl` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rating` int NOT NULL DEFAULT '5',
  `featured` tinyint(1) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testimonial`
--

LOCK TABLES `testimonial` WRITE;
/*!40000 ALTER TABLE `testimonial` DISABLE KEYS */;
INSERT INTO `testimonial` VALUES ('cmnfov2re000enkt05ferw9fm','ทรัพย์โสภา ปิโตรเลียม','เจ้าของปั้ม','จ.ร้อยเอ็ด','ติดตั้ง ATG แบบ Level Sensor ดูออนไลน์สะดวกมากค่ะ ใช้บริการเพิ่มเติมคือโปรแกรมขายน้ำมันใช้งานง่าย โปรแกรมตอบสนองไวมาก หมดปัญหาเรื่องการขายน้ำมันปิดยอดวันขาดเกินได้เลยค่ะ ','/uploads/4c1ebedf-7951-4bfd-9a76-30c0476ecc03.jpg',5,1,1,'2026-04-01 06:52:37.178','2026-04-05 14:46:06.062'),('cmnfov2rh000fnkt0tk8ng234','ทรัพย์อนันต์ ปิโตรเลียม','เจ้าของปั้ม','จ.ตรัง','ติดตั้งระบบ FPOS และ ATG สะดวกขึ้นมากมายเลยครับ ดูระดับน้ำมันแบบทันทีได้สะดวกมาก แนะนำบริการจากบริษัทนี้เลยน้องๆไม่ทิ้งงานอยู่ทำจนจบ ขนาดที่ตรังฝนตกเกือบทุกวันตอนที่มาติดตั้ง','/uploads/a2ad0d1e-b1b6-4f60-a9e4-7cce80e62a11.jpg',5,1,1,'2026-04-01 06:52:37.181','2026-04-05 14:43:25.795'),('cmnfov2rj000gnkt00njlotd1','แสวงหาการเกษตร ปิโตรเลียม','เจ้าของปั้ม','จ.อ่างทอง','ติดตั้งระบบ FPOS โปรแกรมสถานีขายน้ำมันแล้วการขายตรงมากไม่มีตกหล่น โปรแกรมใช้งานได้สะดวก เข้าใจง่ายและมีฟังก์ชั่นอำนวบความสะดวกมากมายและดูยอดขายออนไลน์ได้ทุกที่','/uploads/e3877ebc-e670-41af-919e-a59e50bf30f0.png',5,1,1,'2026-04-01 06:52:37.184','2026-04-05 14:32:38.449'),('cmnlvq6v20000nk041a2grtqy','อุไรวรรณ ปิโตรเลียม','เจ้าของกิจการ',' จ.มหาสารคาม','ติดตั้งโปรแกรมสถานีขายน้ำมันแล้วยอดขายแม่นยำ โปรแกรมเข้าใจง่าย ไม่งอแง เนื่องจากทางปั้มเป็นตู้ true เขาก็สามารถเชื่อมต่อ POS ให้ได้ในราคาถูกกว่าเจ้าใหญ่ครึ่งต่อครึ่ง ฟังก์ชั่นก็เยอะ แถมบริการหลังการติดตั้งดีอีก เริ่ดๆ','/uploads/7a8547ac-b9db-40ac-bcd7-13dba460cd2b.jpg',5,1,1,'2026-04-05 14:51:23.577','2026-04-05 14:51:23.577');
/*!40000 ALTER TABLE `testimonial` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emailVerified` datetime(3) DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'admin',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `User_email_key` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('cmnfo123z0000nkh8be6219j2','Admin','admin@trs.com',NULL,'$2a$12$UInBGQgp.rVLenMes7RVE.b61lO8Cs9/vTtKDs43lb3fUK1NH4MFy',NULL,'admin','2026-04-01 06:29:16.654','2026-04-01 06:52:37.126');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verificationtoken`
--

DROP TABLE IF EXISTS `verificationtoken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `verificationtoken` (
  `identifier` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires` datetime(3) NOT NULL,
  UNIQUE KEY `VerificationToken_token_key` (`token`),
  UNIQUE KEY `VerificationToken_identifier_token_key` (`identifier`,`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verificationtoken`
--

LOCK TABLES `verificationtoken` WRITE;
/*!40000 ALTER TABLE `verificationtoken` DISABLE KEYS */;
/*!40000 ALTER TABLE `verificationtoken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'trs_web'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-06  0:54:30
